<?php
return array (
  'password_hash' => '$2y$12$wdq9ZLzvASyqiGL5W2Ryg.Uy.0FYRM5Vpofm00YLL9bqdmD1ikTWS',
);
