console.log("Szia, JavaScript!");
