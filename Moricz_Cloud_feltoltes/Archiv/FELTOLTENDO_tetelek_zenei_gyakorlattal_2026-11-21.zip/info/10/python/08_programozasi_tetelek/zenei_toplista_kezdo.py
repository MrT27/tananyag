# Gyakorló adatok. A lejátszás- és like-számok a feladathoz megadott értékek.
zene_cimek = ["Shape of You", "Love Story", "Bohemian Rhapsody", "Smells Like Teen Spirit", "Crazy in Love", "Believer", "Bad Guy", "Despacito"]
hossz_mp = [233, 235, 355, 301, 235, 204, 194, 229]
stilusok = ["pop", "pop", "rock", "rock", "r&b", "rock", "pop", "latin"]
spotify_lejatszasok = [380_000_000, 120_000_000, 950_000_000, 800_000_000, 500_000_000, 700_000_000, 650_000_000, 1_200_000_000]
youtube_likeok = [26_000_000, 3_500_000, 19_000_000, 17_000_000, 10_000_000, 16_000_000, 18_000_000, 48_000_000]

# 1. Rockdalok száma
# Számold meg a rock stílusú dalokat! Készíts indexes, közvetlen listabejárásos és count() megoldást is!



# 2. Teljes játékidő
# Add össze a dalok hosszát másodpercben! Oldd meg közvetlen bejárással, indexes ciklussal és sum() használatával!



# 3. Legrövidebb dal
# Keresd meg a legrövidebb dal címét és hosszát! Először ciklussal, majd min() és index() használatával dolgozz!



# 4. Legtöbb Spotify-lejátszás
# Keresd meg a legtöbb Spotify-lejátszással rendelkező dalt! Írd ki a címét és a lejátszások számát! Készíts ciklusos és max() megoldást!



# 5. Love a címben
# Írd ki azokat a dalcímeket, amelyekben szerepel a love szövegrész! A kis- és nagybetűk eltérése ne számítson! Oldd meg indexes és közvetlen bejárással!



# 6. Szerepel-e a Thriller?
# Döntsd el, szerepel-e pontosan a Thriller cím a listában! Készíts korai leállású while ciklusos és in operátoros megoldást!



# 7. Despacito YouTube-like-jai
# Keresd meg a Despacito című dalt, és írd ki a YouTube-like-ok számát! A hiányzó címet is kezeld! Készíts while ciklusos és in/index() megoldást!


