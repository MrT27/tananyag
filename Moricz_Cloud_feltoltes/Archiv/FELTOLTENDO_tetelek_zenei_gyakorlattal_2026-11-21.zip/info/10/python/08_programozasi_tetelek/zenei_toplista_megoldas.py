# Gyakorló adatok. A lejátszás- és like-számok a feladathoz megadott értékek.
zene_cimek = ["Shape of You", "Love Story", "Bohemian Rhapsody", "Smells Like Teen Spirit", "Crazy in Love", "Believer", "Bad Guy", "Despacito"]
hossz_mp = [233, 235, 355, 301, 235, 204, 194, 229]
stilusok = ["pop", "pop", "rock", "rock", "r&b", "rock", "pop", "latin"]
spotify_lejatszasok = [380_000_000, 120_000_000, 950_000_000, 800_000_000, 500_000_000, 700_000_000, 650_000_000, 1_200_000_000]
youtube_likeok = [26_000_000, 3_500_000, 19_000_000, 17_000_000, 10_000_000, 16_000_000, 18_000_000, 48_000_000]

# 1. Rockdalok száma
rock_db = 0
for i in range(len(stilusok)):
    if stilusok[i] == "rock":
        rock_db += 1
print("Rockdalok száma:", rock_db)

rock_db = 0
for stilus in stilusok:
    if stilus == "rock":
        rock_db += 1
print("Rockdalok száma:", rock_db)
print("Rockdalok száma:", stilusok.count("rock"))

# 2. Teljes játékidő
ossz_hossz = 0
for hossz in hossz_mp:
    ossz_hossz += hossz
print("Teljes játékidő:", ossz_hossz, "másodperc")

ossz_hossz = 0
for i in range(len(hossz_mp)):
    ossz_hossz += hossz_mp[i]
print("Teljes játékidő:", ossz_hossz, "másodperc")
print("Teljes játékidő:", sum(hossz_mp), "másodperc")

# 3. Legrövidebb dal
min_ertek = hossz_mp[0]
min_index = 0
for i in range(1, len(hossz_mp)):
    if hossz_mp[i] < min_ertek:
        min_ertek = hossz_mp[i]
        min_index = i
print("Legrövidebb dal:", zene_cimek[min_index], min_ertek, "másodperc")

min_ertek = min(hossz_mp)
min_index = hossz_mp.index(min_ertek)
print("Legrövidebb dal:", zene_cimek[min_index], min_ertek, "másodperc")

# 4. Legtöbb Spotify-lejátszás
max_ertek = spotify_lejatszasok[0]
max_index = 0
for i in range(1, len(spotify_lejatszasok)):
    if spotify_lejatszasok[i] > max_ertek:
        max_ertek = spotify_lejatszasok[i]
        max_index = i
print("Legtöbbet lejátszott dal:", zene_cimek[max_index], max_ertek)

max_ertek = max(spotify_lejatszasok)
max_index = spotify_lejatszasok.index(max_ertek)
print("Legtöbbet lejátszott dal:", zene_cimek[max_index], max_ertek)

# 5. Love a címben
print("Love szövegrészt tartalmazó címek:")
for i in range(len(zene_cimek)):
    if "love" in zene_cimek[i].lower():
        print(zene_cimek[i])

print("Love szövegrészt tartalmazó címek:")
for cim in zene_cimek:
    if "love" in cim.lower():
        print(cim)

# 6. Szerepel-e a Thriller?
i = 0
van_thriller = False
while i < len(zene_cimek) and not van_thriller:
    if zene_cimek[i] == "Thriller":
        van_thriller = True
    i += 1

if van_thriller:
    print("Thriller: Igen, benne van.")
else:
    print("Thriller: Nem, nincs benne.")

van_thriller = "Thriller" in zene_cimek
if van_thriller:
    print("Thriller: Igen, benne van.")
else:
    print("Thriller: Nem, nincs benne.")

# 7. Despacito YouTube-like-jai
i = 0
talalat = False
keresett_cim = "Despacito"
while i < len(zene_cimek) and not talalat:
    if zene_cimek[i] == keresett_cim:
        talalat = True
    else:
        i += 1

if talalat:
    print(keresett_cim, "YouTube-like-jai:", youtube_likeok[i])
else:
    print("Nincs ilyen dal a listában.")

if keresett_cim in zene_cimek:
    index = zene_cimek.index(keresett_cim)
    print(keresett_cim, "YouTube-like-jai:", youtube_likeok[index])
else:
    print("Nincs ilyen dal a listában.")
