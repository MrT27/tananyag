szinek = ["fekete", "piros", "szürke", "szürke", "fehér", "fekete", "zöld", "fekete", "kék", "piros", "kék", "szürke", "zöld", "fehér", "fekete"]
markak = ["Fiat", "Ford", "Ford", "Mazda", "Opel", "Opel", "Opel", "Suzuki", "Suzuki", "Suzuki", "Toyota", "Toyota", "Toyota", "Volkswagen", "Volkswagen"]
futott_km_ek = [146295, 240841, 230723, 257590, 99048, 171159, 305854, 97971, 281036, 165852, 226972, 167449, 254255, 223526, 289309]
szerviz_ota_napok = [96, 101, 22, 236, 287, 72, 191, 305, 322, 113, 293, 209, 123, 94, 79]

# 1. Van-e Mazda?
# Eldöntéssel vizsgáld meg, van-e Mazda márkájú autó a listában! Az első találatnál állítsd le a keresést!



# 2. Van-e Seat?
# Eldöntéssel vizsgáld meg, van-e Seat márkájú autó a listában! Az első találatnál állítsd le a keresést!



# 3. Fekete Opel
# Lineáris kereséssel keresd meg az első fekete Opelt! Ha van ilyen, írd ki a futott kilométereit! A hiányzó találatot is kezeld!



# 4. Zöld Toyota
# Kiválasztással keresd meg a zöld Toyotát, és írd ki, hány napja volt szervizben! A megadott adatok között biztosan van ilyen autó.



# 5. Suzukik száma
# For ciklussal számold meg, hány Suzuki van a listában!



# 6. Fordok összes kilométere
# Feltételes összegzéssel számítsd ki, hány kilométert futottak a Fordok összesen!



# 7. Legkevesebbet futott autó
# Minimumkiválasztással keresd meg a legkevesebbet futott autót! Írd ki a színét, márkáját és futott kilométereit!



# 8. Legrégebbi szerviz
# Maximumkiválasztással keresd meg, melyik autónak volt legrégebben szervize! Írd ki a színét, márkáját és az eltelt napok számát!


