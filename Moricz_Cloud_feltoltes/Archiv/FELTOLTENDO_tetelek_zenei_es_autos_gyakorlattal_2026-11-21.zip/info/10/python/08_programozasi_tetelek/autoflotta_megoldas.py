szinek = ["fekete", "piros", "szürke", "szürke", "fehér", "fekete", "zöld", "fekete", "kék", "piros", "kék", "szürke", "zöld", "fehér", "fekete"]
markak = ["Fiat", "Ford", "Ford", "Mazda", "Opel", "Opel", "Opel", "Suzuki", "Suzuki", "Suzuki", "Toyota", "Toyota", "Toyota", "Volkswagen", "Volkswagen"]
futott_km_ek = [146295, 240841, 230723, 257590, 99048, 171159, 305854, 97971, 281036, 165852, 226972, 167449, 254255, 223526, 289309]
szerviz_ota_napok = [96, 101, 22, 236, 287, 72, 191, 305, 322, 113, 293, 209, 123, 94, 79]

# 1. Van-e Mazda?
talalat = False
i = 0
while i < len(markak) and not talalat:
    if markak[i] == "Mazda":
        talalat = True
    i += 1

if talalat:
    print("Van a listában Mazda.")
else:
    print("Nincs a listában Mazda.")

# 2. Van-e Seat?
talalat = False
i = 0
while i < len(markak) and not talalat:
    if markak[i] == "Seat":
        talalat = True
    i += 1

if talalat:
    print("Van a listában Seat.")
else:
    print("Nincs a listában Seat.")

# 3. Fekete Opel
talalat = False
i = 0
while i < len(markak) and not talalat:
    if markak[i] == "Opel" and szinek[i] == "fekete":
        talalat = True
    else:
        i += 1

if talalat:
    print(f"A fekete Opel {futott_km_ek[i]:,} km-t futott eddig.")
else:
    print("Nincs a listában fekete Opel.")

# 4. Zöld Toyota
i = 0
while not (markak[i] == "Toyota" and szinek[i] == "zöld"):
    i += 1

print(f"A zöld Toyota {szerviz_ota_napok[i]} napja volt utoljára szervizben.")

# 5. Suzukik száma
szamlalo = 0
for marka in markak:
    if marka == "Suzuki":
        szamlalo += 1

print(f"{szamlalo} db Suzuki van a listában.")

# 6. Fordok összes kilométere
km_osszesen = 0
for i in range(len(markak)):
    if markak[i] == "Ford":
        km_osszesen += futott_km_ek[i]

print(f"A Ford autók eddig {km_osszesen:,} km-t futottak összesen.")

# 7. Legkevesebbet futott autó
min_km = futott_km_ek[0]
min_index = 0
for i in range(1, len(futott_km_ek)):
    if futott_km_ek[i] < min_km:
        min_km = futott_km_ek[i]
        min_index = i

print(f"A {szinek[min_index]} {markak[min_index]} futott a legkevesebbet: {min_km:,} km.")

# 8. Legrégebbi szerviz
max_szerviz = szerviz_ota_napok[0]
max_index = 0
for i in range(1, len(szerviz_ota_napok)):
    if szerviz_ota_napok[i] > max_szerviz:
        max_szerviz = szerviz_ota_napok[i]
        max_index = i

print(f"A {szinek[max_index]} {markak[max_index]} volt legrégebben szervizben: {max_szerviz} napja.")
