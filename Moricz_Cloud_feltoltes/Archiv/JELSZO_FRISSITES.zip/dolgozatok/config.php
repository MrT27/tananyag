<?php
return array (
  'password_hash' => '$2y$12$M1G0/J7VfK9AKSNDQPM8ZO2kaT2M9moipADzL39TINYjG7jOpiKXe',
);
