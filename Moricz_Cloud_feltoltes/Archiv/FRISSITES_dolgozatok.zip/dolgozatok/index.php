<?php
declare(strict_types=1);
ini_set('session.use_strict_mode','1');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','samesite'=>'Strict']);
session_start();
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
const GUARD = "<?php exit; ?>\n";
$dir=__DIR__.'/adatok';
$config=require __DIR__.'/config.php';
function h(string $s):string{return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}
function items():array {global $dir;$p=$dir.'/lista.php';return is_file($p)?json_decode(substr(file_get_contents($p),strlen(GUARD)),true,512,JSON_THROW_ON_ERROR):[];}
function saveItems(array $items):void {global $dir;$temp=tempnam($dir,'lista-');file_put_contents($temp,GUARD.json_encode($items,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));rename($temp,$dir.'/lista.php');}
$_SESSION['csrf']??=bin2hex(random_bytes(24));
$error='';$notice='';$admin=isset($_GET['admin']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals($_SESSION['csrf'],(string)($_POST['csrf']??''))){http_response_code(403);exit('A munkamenet lejárt. Frissítsd az oldalt!');}
 $action=$_POST['action']??'';
 if($action==='login'){
  $lock=fopen($dir.'/belepes.php','c+');flock($lock,LOCK_EX);$raw=stream_get_contents($lock);$attempt=$raw?json_decode(substr($raw,strlen(GUARD)),true):['start'=>time(),'count'=>0];
  if(time()-$attempt['start']>900)$attempt=['start'=>time(),'count'=>0];
  if($attempt['count']>=20){$error='Túl sok belépési kísérlet. Próbáld újra 15 perc múlva!';}
  elseif(password_verify((string)($_POST['password']??''),$config['password_hash'])){session_regenerate_id(true);$_SESSION['auth']=true;$attempt=['start'=>time(),'count'=>0];}
  else{$attempt['count']++;$error='Hibás jelszó.';}
  rewind($lock);ftruncate($lock,0);fwrite($lock,GUARD.json_encode($attempt));flock($lock,LOCK_UN);fclose($lock);
 }elseif(!empty($_SESSION['auth'])){
  if($action==='logout'){$_SESSION=[];session_destroy();header('Location: ?admin');exit;}
  $lock=fopen($dir.'/modositas.php','c+');flock($lock,LOCK_EX);$list=items();
  try{
   if($action==='upload'){
    $title=trim((string)($_POST['title']??''));$group=(string)($_POST['group']??'');
    if($title===''||mb_strlen($title)>120)throw new RuntimeException('Adj meg legfeljebb 120 karakteres címet!');
    if(!in_array($group,['9. évfolyam','10. évfolyam','11. évfolyam','12. évfolyam'],true))throw new RuntimeException('Válassz évfolyamot!');
    $subject=trim((string)($_POST['subject']??''));if($subject===''||mb_strlen($subject)>80)throw new RuntimeException('Add meg a tantárgyat, legfeljebb 80 karakterben!');
    $f=$_FILES['file']??[];
    if(($f['error']??-1)!==UPLOAD_ERR_OK)throw new RuntimeException('A feltöltés sikertelen. Válassz ki egy PDF- vagy TXT-fájlt!');
    if($f['size']>10*1024*1024)throw new RuntimeException('Legfeljebb 10 MB-os fájl tölthető fel.');
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if($ext==='pdf'){
     if($mime!=='application/pdf'||file_get_contents($f['tmp_name'],false,null,0,5)!=='%PDF-')throw new RuntimeException('A kiválasztott fájl nem érvényes PDF.');
    }elseif($ext==='txt'){
     $content=file_get_contents($f['tmp_name']);
     if(($mime!=='text/plain' && $f['size']!==0)||str_contains($content,"\0"))throw new RuntimeException('A TXT-fájl egyszerű szöveget tartalmazzon!');
    }else{throw new RuntimeException('Csak PDF- vagy TXT-fájl tölthető fel.');}
    $id=bin2hex(random_bytes(16));
    if(file_put_contents($dir.'/'.$id.'.php',GUARD.file_get_contents($f['tmp_name']))===false)throw new RuntimeException('A tárhelyre nem sikerült írni.');
    $list[$id]=['type'=>$ext,'title'=>$title,'group'=>$group,'subject'=>$subject,'visible'=>isset($_POST['visible']),'date'=>date('Y-m-d')];saveItems($list);$notice='A dolgozat feltöltve.';
   }elseif($action==='delete'){
    $id=(string)($_POST['id']??'');
    if(preg_match('/^[a-f0-9]{32}$/',$id)&&isset($list[$id])){
     $path=$dir.'/'.$id.'.php';
     if(is_file($path)&&!unlink($path))throw new RuntimeException('A fájlt nem sikerült törölni.');
     unset($list[$id]);saveItems($list);$notice='A dolgozat törölve.';
    }
   }elseif($action==='toggle'){
    $id=(string)($_POST['id']??'');if(isset($list[$id])){$list[$id]['visible']=!$list[$id]['visible'];saveItems($list);$notice='A láthatóság módosítva.';}
   }
  }catch(Throwable $e){$error=$e->getMessage();}
  flock($lock,LOCK_UN);fclose($lock);
 }
}
$list=items();
if(isset($_GET['download'])){
 $id=(string)$_GET['download'];$item=$list[$id]??null;
 if(!$item||(!$item['visible']&&empty($_SESSION['auth']))||!preg_match('/^[a-f0-9]{32}$/',$id)){http_response_code(404);exit('A dolgozat nem érhető el.');}
 $f=fopen($dir.'/'.$id.'.php','rb');fseek($f,strlen(GUARD));$ext=$item['type']??'pdf';header('Content-Type: '.($ext==='txt'?'text/plain; charset=UTF-8':'application/pdf'));$name=trim(preg_replace('/[\x00-\x1F\x7F\\\\\/<>:"|?*]+/u','-', $item['title']), " .-\t\n\r");
 $name=preg_replace('/\.(pdf|txt)$/iu','',$name);
 if($name==='')$name='dolgozat';
 $name.='.'.$ext;
 $ascii=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$name);
 $ascii=preg_replace('/[^a-zA-Z0-9._ -]/','-',$ascii?:'dolgozat.'.$ext);
 header("Content-Disposition: attachment; filename=\"".$ascii."\"; filename*=UTF-8''".rawurlencode($name));fpassthru($f);exit;
}
?>
<!doctype html><html lang="hu"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= $admin?'Tanári feltöltés':'Dolgozatok' ?></title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fa;color:#202733;font:17px/1.5 Arial,sans-serif}main{max-width:780px;margin:auto;padding:24px 16px}h1{font-size:30px}h2{font-size:21px;margin:0 0 10px}.card{background:white;border:1px solid #dce2e9;border-radius:12px;padding:22px;margin:18px 0}label{display:block;font-weight:bold;margin:15px 0 6px}input:not([type=checkbox]),select{width:100%;padding:12px;font:inherit;border:1px solid #a9b4c2;border-radius:7px}input[type=checkbox]{width:22px;height:22px;vertical-align:middle}button,.button{display:inline-block;background:#1263dc;color:white;border:0;border-radius:7px;padding:13px 20px;font:inherit;text-decoration:none;cursor:pointer;margin-top:12px}.secondary{background:#526174}.danger{background:#b42332}.delete-confirm{margin-top:12px}.delete-confirm summary{display:inline-block;background:#b42332;color:white;border-radius:7px;padding:13px 20px;cursor:pointer}.delete-confirm p{margin-bottom:0}small,.muted{color:#586573}.error{background:#ffe8e8;padding:14px}.notice{background:#def4e8;padding:14px}.row{display:flex;flex-wrap:wrap;gap:12px;align-items:center}a{color:#1255ac}
</style></head><body><main><h1><?= $admin?'Tanári feltöltés':'Dolgozatok' ?></h1>
<?php if($error):?><p class="error"><?=h($error)?></p><?php endif ?><?php if($notice):?><p class="notice"><?=h($notice)?></p><?php endif ?>
<?php function csrf():void{echo '<input type="hidden" name="csrf" value="'.h($_SESSION['csrf']).'">';} ?>
<?php if($admin && empty($_SESSION['auth'])):?>
<section class="card"><h2>Belépés</h2><form method="post"><?php csrf()?><input type="hidden" name="action" value="login"><label for="password">Tanári jelszó</label><input id="password" name="password" type="password" autocomplete="current-password" required><button>Belépés</button></form></section>
<?php elseif($admin):?>
<p>Válaszd ki a dolgozatot, majd add meg, hol jelenjen meg!</p>
<section class="card"><h2>Új dolgozat</h2><form method="post" enctype="multipart/form-data"><?php csrf()?><input type="hidden" name="action" value="upload">
<label for="title">Dolgozat címe</label><input id="title" name="title" maxlength="120" placeholder="JavaScript-alapok – dolgozat" required>
<label for="group">Évfolyam</label><select id="group" name="group"><?php foreach(['9. évfolyam','10. évfolyam','11. évfolyam','12. évfolyam'] as $g):?><option <?=$g==='11. évfolyam'?'selected':''?>><?=h($g)?></option><?php endforeach?></select>
<label for="subject">Tantárgy / témakör</label><input id="subject" name="subject" value="Programozás – JavaScript" maxlength="80" required>
<label for="file">Feladatlap (PDF vagy TXT, legfeljebb 10 MB)</label><input id="file" name="file" type="file" accept="application/pdf,text/plain,.pdf,.txt" required>
<label><input type="checkbox" name="visible" checked> Feltöltés után látható legyen a diákoknak</label><button>Dolgozat feltöltése</button></form></section>
<div class="row"><a class="button secondary" href="./" target="_blank" rel="noopener">Diákoldal megtekintése</a><form method="post"><?php csrf()?><input type="hidden" name="action" value="logout"><button class="secondary">Kilépés</button></form></div>
<?php endif ?>
<?php if(!$admin||!empty($_SESSION['auth'])):?>
<?php $shown=0;foreach(array_reverse($list,true) as $id=>$item):if(!$admin&&!$item['visible'])continue;$shown++;?>
<section class="card"><small><?=h($item['group'])?> · <?=h($item['subject'])?> · <?=strtoupper(h($item['type']??'pdf'))?></small><h2><?=h($item['title'])?></h2><p class="muted"><?=h($item['date'])?><?=$admin?' · '.($item['visible']?'Látható a diákoknak':'Elrejtve'):''?></p><a class="button" href="?download=<?=h($id)?>">Feladatlap letöltése</a>
<?php if($admin):?><form method="post"><?php csrf()?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=h($id)?>"><button class="secondary"><?=$item['visible']?'Elrejtés':'Közzététel'?></button></form><details class="delete-confirm"><summary>Törlés</summary><p>Végleg törlöd ezt a dolgozatot és a hozzá tartozó fájlt? Ez nem vonható vissza. Ha mégsem szeretnéd, csukd vissza a Törlés gombbal.</p><form method="post"><?php csrf()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=h($id)?>"><button class="danger">Igen, végleg törlöm</button></form></details><?php endif ?></section>
<?php endforeach;if(!$shown):?><p class="card"><?=$admin?'Még nincs feltöltött dolgozat.':'Jelenleg nincs közzétett dolgozat.'?></p><?php endif ?>
<?php endif ?><p><a class="button secondary" href="../index.html">Vissza a kezdőoldalra</a></p></main></body></html>
